import datetime

from django.http import HttpResponse




def myapp(request):
    date = datetime.datetime.now()
    return HttpResponse("<h1>This is my starting project of Django</h1>" + str(date) )

