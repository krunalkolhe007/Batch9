import datetime

from django.http import HttpResponse
from django.shortcuts import render




def myapp(request):
    date = datetime.datetime.now()
    return HttpResponse("<h1>This is my starting project of Django</h1>" + str(date) )

def home(request):
    # return HttpResponse("<h1>this is my home page</h1>")
    return render(request,"home.html",{})


def about(request):
    # return HttpResponse("<h1>this is my about us page you are looking for</h1>")
    return render(request,"aboutus.html",{})

def contact(request):
    # return HttpResponse("<h1>this is my Feedback page where user is giving their valuable feedback</h1>")
    return render(request,"contactus.html",{})

def services(request):
    return render
    
    

