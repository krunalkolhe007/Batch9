import datetime

from django.http import HttpResponse




def myapp(request):
    date = datetime.datetime.now()
    return HttpResponse("<h1>This is my starting project of Django</h1>" + str(date) )

def homepage(request):
    return HttpResponse("<h1>this is my home page</h1>")


def about(request):
    return HttpResponse("<h1>this is my about us page you are looking for</h1>")


def feedback(request):
    return HttpResponse("<h1>this is my Feedback page where user is giving their valuable feedback</h1>")

