import datetime

from django.http import HttpResponse
from django.shortcuts import render




def myapp(request):
    date = datetime.datetime.now()
    return HttpResponse("<h1>This is my starting project of Django</h1>" + str(date) )

def home(request):
    if request.method == 'POST':
       checked = request.POST['checked']
       print(checked)
    # return HttpResponse("<h1>this is my home page</h1>")
    name = "SkillREX Institute of Technologies"
    isActivated = True
    
    list_of_phrases=[
        'Success is a series of little daily victories',
        'A man can succeed at anything for which he has unlimited enthausisum',
        'A king will be king if he will not act as a king',
    ]
    employee ={
        'employee_name' : "Nayan",
        'employee_office' : "TCS",
        'employee_designation' : "FullStack Engineer",
        'employee_city' : "Pune"
    }

    data = {
        'name':name,
        'list_of_phrases':list_of_phrases,
        'employee_data':employee

    }

    return render(request,"home.html",data)


def about(request):
    # return HttpResponse("<h1>this is my about us page you are looking for</h1>")
  return render(request,"aboutus.html",{})

def contact(request):
    # return HttpResponse("<h1>this is my Feedback page where user is giving their valuable feedback</h1>")
    return render(request,"contactus.html",{})

def services(request):
    return render(request,"services.html",{})
    

    

