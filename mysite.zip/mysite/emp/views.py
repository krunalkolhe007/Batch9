from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Emp
# Create your views here.


def employee_home(request):

    emps = Emp.objects.all()
    return render(request, "emp/home.html",{
        'emps': emps
    })
        

def add_emp(request):
    if request.method=="POST":
       
        # data fetch

        emp_id = request.POST.get("emp_id")
        emp_phone = request.POST.get("emp_phone")
        emp_address = request.POST.get("emp_address")
        emp_working = request.POST.get("emp_working")
        emp_department = request.POST.get("emp_department")


        # create model object and set the data

        e = Emp()
        e.emp_id = emp_id
        e.phone = emp_phone
        e.address = emp_address
        e.department = emp_department
        if emp_working is None:
            e.working = False
        else:
            e.working = True

        # save the object

        e.save()

        # typing or printing


        return redirect("/employee/home/")
    return render(request, "emp/add_emp.html",{})


def delete_emp(request,emp_id):
    emp = Emp.objects.get(pk=emp_id)
    emp.delete()
    return redirect("/employee/home/")