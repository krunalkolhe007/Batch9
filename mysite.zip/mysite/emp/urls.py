from django.contrib import admin
from django.urls import path,include

from .views import *

urlpatterns = [
path("home/", employee_home),

# add employee
path("add-emp/",add_emp),

# delete employee
path("delete-emp/<int:emp_id>",delete_emp),


]


