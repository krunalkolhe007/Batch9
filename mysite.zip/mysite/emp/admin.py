from django.contrib import admin
from .models import Emp_new


# Register your models here.

admin.site.register(Emp_new)

